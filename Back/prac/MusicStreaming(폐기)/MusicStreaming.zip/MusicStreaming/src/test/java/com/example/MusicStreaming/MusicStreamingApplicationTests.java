package com.example.MusicStreaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicStreamingApplicationTests {

	@Test
	void contextLoads() {
	}

}
